# =====================================================================
#  Segment-Level Cost Decomposition — reproducible analysis
#  Requires: lme4, dplyr, ggplot2, boot, effsize
# =====================================================================
library(lme4); library(dplyr); library(ggplot2); library(boot); library(effsize)
set.seed(2026)

# ---- 1. Data -------------------------------------------------------
csv <- "data/segment_times.csv"
if (!file.exists(csv)) stop("No encuentro ", csv, " — directorio actual: ", getwd())
dat <- segment_times

geom <- data.frame(
  segment = 1:10,
  d    = c(5.000, 4.000, 2.236, 3.000, 2.000, 2.000, 2.236, 2.828, 4.123, 10.000),
  dpsi = c(0.00, 90.00, 153.43, 63.43, 0.00, 90.00, 153.43, 108.43, 120.96, 104.04))
dat <- left_join(dat, geom, by = "segment")

stopifnot(nrow(dat) == 100, all(table(dat$segment) == 10), !anyNA(dat$time_s))
mission <- dat %>% group_by(trial) %>% summarise(T = sum(time_s), .groups = "drop")
Tbar <- mean(mission$T); Sd <- sum(geom$d); Spsi <- sum(geom$dpsi)
cat(sprintf("Mission %.1f s | SD %.2f | CV %.2f%% | range %.0f-%.0f s\n",
            Tbar, sd(mission$T), 100*sd(mission$T)/Tbar,
            min(dat$time_s), max(dat$time_s)))

# ---- 2. Inter-run variability -------------------------------------
lmm <- lmer(time_s ~ d + dpsi + (1 | trial), data = dat, REML = TRUE)
vc  <- as.data.frame(VarCorr(lmm))
cat(sprintf("ICC = %.2e (boundary estimate)\n", vc$vcov[1] / sum(vc$vcov)))

ols <- lm(time_s ~ d + dpsi, data = dat)
print(summary(aov(residuals(ols) ~ factor(dat$trial))))

# ---- 3. Lack of fit — exact ---------------------------------------
sat <- lm(time_s ~ factor(segment), data = dat)
lof <- anova(ols, sat); print(lof)
sigma_pure <- sigma(sat)
SSE <- sum(residuals(ols)^2); SSPE <- sum(residuals(sat)^2)
cat(sprintf("Pure error SD %.2f s | RMSE %.2f s | %.0f%% systematic | bias SD %.2f s\n",
            sigma_pure, sigma(ols), 100*(SSE - SSPE)/SSE, sqrt((SSE - SSPE)/10/10)))

# ---- 4. Segment-mean regression -> reported SEs (Table 2) ---------
means <- dat %>% group_by(segment, d, dpsi) %>%
  summarise(ybar = mean(time_s), .groups = "drop")
fitm <- lm(ybar ~ d + dpsi, data = means)
print(summary(fitm)); print(confint(fitm))
cf <- coef(fitm); se <- summary(fitm)$coefficients[, 2]; tc <- qt(.975, 7)
cat(sprintf("beta^-1 = %.4f m/s | gamma^-1 = %.3f rad/s | 90deg = %.2f s\n",
            1/cf["d"], pi/180/cf["dpsi"], 90*cf["dpsi"]))

# ---- 5. Attribution (Table 3) -------------------------------------
sef <- (Sd/Tbar)*se["d"]; sh <- cf["d"]*Sd/Tbar
cat(sprintf("Translation %.1f%% [%.1f, %.1f] | Non-productive %.1f%% [%.1f, %.1f]\n",
            100*sh, 100*(sh-tc*sef), 100*(sh+tc*sef),
            100*(1-sh), 100*(1-sh-tc*sef), 100*(1-sh+tc*sef)))
cat(sprintf("Overhead %.1f s [%.1f, %.1f] | Rotation %.1f s [%.1f, %.1f] | ratio %.2f\n",
            10*cf[1], 10*(cf[1]-tc*se[1]), 10*(cf[1]+tc*se[1]),
            Spsi*cf["dpsi"], Spsi*(cf["dpsi"]-tc*se["dpsi"]), Spsi*(cf["dpsi"]+tc*se["dpsi"]),
            10*cf[1]/(Spsi*cf["dpsi"])))

# ---- 6. Cluster bootstrap (robustness check only) -----------------
bs <- boot(1:10, R = 5000, statistic = function(ids, i) {
  dd <- do.call(rbind, lapply(ids[i], function(s) dat[dat$segment == s, ]))
  1 - coef(lm(time_s ~ d + dpsi, data = dd))["d"]*Sd/Tbar })
print(boot.ci(bs, type = "perc"))

# ---- 7. Segment contrasts ------------------------------------------
for (p in list(c(3,7), c(5,6))) {
  A <- dat$time_s[dat$segment == p[1]]; B <- dat$time_s[dat$segment == p[2]]
  tt <- t.test(A, B)
  cat(sprintf("S%d %.1f vs S%d %.1f | diff %.1f s | t=%.2f p=%.2e | MW p=%.5f | d=%.2f\n",
              p[1], mean(A), p[2], mean(B), mean(B)-mean(A), tt$statistic, tt$p.value,
              wilcox.test(A, B)$p.value, abs(cohen.d(A, B)$estimate)))
}

# ---- 8. Figure 3 — lack-of-fit diagnostic --------------------------
band <- 1.96*sigma_pure/sqrt(10)
diag <- means %>% mutate(bias = ybar - predict(fitm),
                         out = abs(bias) > band,
                         lab = factor(paste0("S", segment),
                                      levels = paste0("S", 1:10)))
fig3 <- ggplot(diag, aes(lab, bias)) +
  annotate("rect", xmin = -Inf, xmax = Inf, ymin = -band, ymax = band,
           fill = "grey85") +
  geom_hline(yintercept = 0, colour = "grey30", linewidth = .4) +
  geom_segment(aes(xend = lab, y = 0, yend = bias), colour = "grey55") +
  geom_point(aes(fill = out), shape = 21, size = 3.2, stroke = .9) +
  scale_fill_manual(values = c(`FALSE` = "white", `TRUE` = "#C0392B"),
                    guide = "none") +
  labs(x = "Mission segment", y = "Observed - predicted (s)",
       subtitle = sprintf("Lack of fit: F(7,90) = %.1f, p = %.1e | pure-error band +/-%.2f s",
                          lof$F[2], lof$`Pr(>F)`[2], band)) +
  ylim(-5.2, 5.2) +
  theme_minimal(base_size = 11) +
  theme(panel.grid.minor = element_blank(),
        plot.subtitle = element_text(size = 8, colour = "grey30"))

dir.create("figures", showWarnings = FALSE)
ggsave("figures/figure3_lackoffit.png", fig3, width = 6.6, height = 2.7, dpi = 400)

# ---- 9. Figure 2 — four-panel model fit and attribution ------------
library(patchwork); library(viridis)

cfo  <- coef(fitm); a <- cfo[1]; b <- cfo["d"]; g <- cfo["dpsi"]
R2   <- summary(ols)$r.squared; RMSE <- sigma(ols)

seg <- dat %>% group_by(segment, d, dpsi) %>%
  summarise(mean = mean(time_s), sd = sd(time_s), .groups = "drop") %>%
  mutate(pred  = a + b*d + g*dpsi,
         trans = b*d, fixed = a, rot = g*dpsi,
         veff  = d/mean,
         lab   = factor(paste0("S", segment), levels = paste0("S", 1:10)))

th <- theme_minimal(base_size = 8) +
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_line(linewidth = .25, colour = "grey88"),
        legend.key.size  = unit(7, "pt"),
        legend.title     = element_blank(),
        legend.text      = element_text(size = 5.8),
        legend.background = element_rect(fill = alpha("white", .9), colour = NA),
        plot.tag = element_text(size = 10, face = "bold"))

# (a) observed vs predicted
pa <- ggplot(seg, aes(pred, mean)) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed",
              colour = "grey45", linewidth = .35) +
  geom_errorbar(aes(ymin = mean - sd, ymax = mean + sd),
                width = 0, colour = "grey40", linewidth = .35) +
  geom_point(size = 1.9, shape = 21, fill = "#2E5F8A",
             colour = "black", stroke = .3) +
  geom_text(aes(label = lab), size = 1.9, colour = "grey25",
            hjust = -0.35, vjust = 1.2) +
  annotate("text", x = 29, y = 100, hjust = 0, size = 2.3,
           label = sprintf("R^2 == %.3f", R2), parse = TRUE) +
  annotate("text", x = 29, y = 94, hjust = 0, size = 2.3,
           label = sprintf("RMSE = %.2f s", RMSE)) +
  coord_cartesian(xlim = c(27, 102), ylim = c(27, 102)) +
  labs(x = "Predicted segment time (s)", y = "Observed segment time (s)") + th

# (b) distribution across executions
pb <- ggplot(dat, aes(factor(segment), time_s)) +
  geom_boxplot(fill = "#D8E3ED", colour = "grey35", linewidth = .3,
               outlier.size = .5, outlier.shape = 21, fatten = 1.4) +
  geom_point(data = seg, aes(lab, pred, shape = "Model prediction"),
             fill = "#E8A33D", colour = "black", size = 1.9, stroke = .3) +
  scale_shape_manual(values = 23) +
  labs(x = "Mission segment", y = "Segment time (s)") +
  th + theme(legend.position = c(.20, .93))

# (c) stacked attribution
comp <- seg %>%
  tidyr::pivot_longer(c(trans, fixed, rot), names_to = "k", values_to = "v") %>%
  mutate(k = factor(k, levels = c("rot", "fixed", "trans"),
                    labels = c("In-place reorientation",
                               "Fixed per-waypoint overhead",
                               "Productive translation")))
pc <- ggplot(comp, aes(lab, v, fill = k)) +
  geom_col(colour = "black", linewidth = .2, width = .72) +
  geom_point(data = seg, aes(lab, mean), inherit.aes = FALSE,
             size = .9, colour = "black") +
  scale_fill_manual(values = c("Productive translation"      = "#2E5F8A",
                               "Fixed per-waypoint overhead" = "#C0504D",
                               "In-place reorientation"      = "#E8A33D"),
                    breaks = c("Productive translation",
                               "Fixed per-waypoint overhead",
                               "In-place reorientation")) +
  labs(x = "Mission segment", y = "Time (s)") +
  th + theme(legend.position = c(.30, .88))

# (d) effective speed vs cumulative heading change
pd <- ggplot(seg, aes(dpsi, veff, fill = d)) +
  geom_hline(yintercept = 1/b, linetype = "dashed",
             colour = "#C0504D", linewidth = .35) +
  annotate("text", x = 170, y = 1/b + .008, hjust = 1, size = 2.0,
           colour = "#C0504D",
           label = sprintf("Pure-translation ceiling %.3f m/s", 1/b)) +
  geom_point(size = 2.3, shape = 21, colour = "black", stroke = .3) +
  geom_text(aes(label = lab), size = 1.9, colour = "grey25",
            hjust = -0.45, vjust = 0.6) +
  scale_fill_viridis_c(name = "Segment\nlength (m)") +
  coord_cartesian(xlim = c(-12, 172), ylim = c(0, .155)) +
  labs(x = "Cumulative heading change (deg)", y = "Effective speed (m/s)") +
  th + theme(legend.title = element_text(size = 5.8),
             legend.key.height = unit(16, "pt"))

fig2 <- (pa | pb) / (pc | pd) + plot_annotation(tag_levels = "a",
                                                tag_prefix = "(", tag_suffix = ")")

ggsave("figures/figure2_composite.png", fig2,
       width = 6.6, height = 4.4, dpi = 400)

